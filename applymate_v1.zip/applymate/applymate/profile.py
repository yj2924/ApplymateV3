"""Candidate profile: schema, demo data, load/save.

The profile is the single source of truth. ApplyMate only ever *selects and
reorders* facts from it; it never invents new ones.
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

DATA_DIR = Path(__file__).resolve().parent.parent / "data"
PROFILE_PATH = DATA_DIR / "profile.json"

# A fictional candidate so the app is fully usable out of the box.
DEMO_PROFILE: dict = {
    "name": "Alex Chen",
    "email": "alex.chen@example.com",
    "phone": "+1 (555) 010-2000",
    "location": "New York, NY",
    "links": ["github.com/alexchen-demo"],
    "work_authorization": {"status": "F-1 OPT (STEM)", "needs_sponsorship": True},
    "graduation": "2026-12",
    "available_from": "2027-01",
    "education": [
        {
            "school": "Example University", "location": "New York, NY",
            "degree": "MS in Statistics", "start": "2025-09", "end": "2026-12", "gpa": "3.7",
            "coursework": ["Applied Machine Learning", "Statistical Inference", "Causal Inference", "Time Series"],
        },
        {
            "school": "State University", "location": "Davis, CA",
            "degree": "BS in Applied Mathematics", "start": "2021-09", "end": "2025-06", "gpa": "3.6",
            "coursework": ["Probability", "Regression Analysis", "Python Programming"],
        },
    ],
    "experiences": [
        {
            "org": "Northwind Retail", "role": "Data Science Intern", "location": "Seattle, WA",
            "start": "2026-06", "end": "2026-08",
            "bullets": [
                {"text": "Built a gradient-boosted churn model on 120,000 loyalty members, improving recall by 9% over the existing rules",
                 "skills": ["Python", "Machine Learning"]},
                {"text": "Designed and analyzed an A/B test of email cadence across 40,000 users, lifting 30-day retention by 2.1 points",
                 "skills": ["A/B Testing", "Statistics", "SQL"]},
                {"text": "Automated a weekly KPI dashboard in Tableau, replacing a 4-hour manual Excel report",
                 "skills": ["Tableau", "Data Visualization", "Excel", "SQL"]},
            ],
        },
        {
            "org": "Contoso Bank", "role": "Risk Analytics Intern", "location": "Charlotte, NC",
            "start": "2025-06", "end": "2025-08",
            "bullets": [
                {"text": "Segmented 25,000 credit card accounts with K-Means and profiled each segment's default risk",
                 "skills": ["Machine Learning", "Risk Management", "Python"]},
                {"text": "Wrote SQL to reconcile 15 transaction tables, cutting data-quality incidents by 30%",
                 "skills": ["SQL"]},
            ],
        },
    ],
    "projects": [
        {"name": "JobLens", "subtitle": "LLM resume screener", "year": "2026",
         "bullets": [{"text": "Built an LLM tool that extracts JD requirements into validated JSON and scores fit, with a rule-based fallback",
                      "skills": ["LLM / GenAI", "Python"]}]},
        {"name": "Transit Forecast", "subtitle": "Course project", "year": "2026",
         "bullets": [{"text": "Forecast daily subway ridership with SARIMA and gradient boosting; reduced MAPE from 11% to 7%",
                      "skills": ["Time Series", "Machine Learning", "Python"]}]},
    ],
    # show: always | if_required (only when the JD asks for it) | never
    "skills": [
        {"name": "Python", "show": "always"}, {"name": "SQL", "show": "always"},
        {"name": "R", "show": "always"}, {"name": "Tableau", "show": "always"},
        {"name": "Excel", "show": "always"}, {"name": "Git", "show": "always"},
        {"name": "Machine Learning", "show": "always"}, {"name": "Statistics", "show": "always"},
        {"name": "A/B Testing", "show": "always"}, {"name": "Time Series", "show": "always"},
        {"name": "Data Visualization", "show": "always"}, {"name": "LLM / GenAI", "show": "always"},
        {"name": "Risk Management", "show": "if_required"}, {"name": "Communication", "show": "if_required"},
        {"name": "Mandarin", "show": "if_required"}, {"name": "SAS", "show": "never"},
    ],
    "interests": "Bouldering, film photography",
    "preferences": {
        "target_roles": ["Data Scientist", "Data Analyst", "Product Analyst", "Business Analyst", "Product Manager"],
        "excluded_role_keywords": ["sales", "software engineer", "research scientist"],
        "blocked_companies": [],
        "max_years_required": 0,
        "preferred_hit_threshold": 0.8,
        "count_unknown_as_miss": True,
        "reject_if_enrollment_required": True,
    },
    "writing": {"no_dashes": True, "sign_off": "Sincerely,"},
}


def load_profile() -> dict:
    if PROFILE_PATH.exists():
        with open(PROFILE_PATH, encoding="utf-8") as f:
            return json.load(f)
    return copy.deepcopy(DEMO_PROFILE)


def save_profile(profile: dict) -> None:
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    with open(PROFILE_PATH, "w", encoding="utf-8") as f:
        json.dump(profile, f, ensure_ascii=False, indent=2)


def is_demo(profile: dict) -> bool:
    return profile.get("email") == DEMO_PROFILE["email"]


def profile_skill_names(profile: dict, include_never: bool = False) -> set[str]:
    """Canonical skills the candidate can honestly claim: listed skills plus skills tagged on bullets."""
    from .skills import normalize

    names = {normalize(s["name"]) for s in profile.get("skills", [])
             if include_never or s.get("show") != "never"}
    for block in profile.get("experiences", []) + profile.get("projects", []):
        for b in block.get("bullets", []):
            names.update(normalize(s) for s in b.get("skills", []))
    return names


def all_bullets(profile: dict):
    """Yield (kind, block, bullet) for every bullet in the profile."""
    for kind in ("experiences", "projects"):
        for block in profile.get(kind, []):
            for b in block.get("bullets", []):
                yield kind, block, b
