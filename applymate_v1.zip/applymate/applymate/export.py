"""Render tailored content as Markdown or a one-page Word resume / cover letter."""
from __future__ import annotations

import io
from datetime import date

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_TAB_ALIGNMENT
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Pt, Inches

from .tailor import Tailored


def _fmt(ym: str) -> str:
    try:
        y, m = ym.split("-")[:2]
        return date(int(y), int(m), 1).strftime("%b %Y")
    except Exception:
        return ym or ""


def _span(block: dict) -> str:
    end = block.get("end", "")
    return f"{_fmt(block.get('start', ''))} – {_fmt(end) if end else 'Present'}"


def contact_line(profile: dict) -> str:
    parts = [profile.get("phone"), profile.get("email"), profile.get("location"), *profile.get("links", [])]
    return " | ".join(p for p in parts if p)


def resume_markdown(profile: dict, t: Tailored) -> str:
    out = [f"# {profile.get('name', '')}", contact_line(profile), "", "## Education"]
    for e in profile.get("education", []):
        gpa = f" (GPA {e['gpa']})" if e.get("gpa") else ""
        out.append("")
        out.append(f"**{e['school']}**, {e['degree']}{gpa}, {_span(e)}")
        if e.get("coursework"):
            out.append(f"- Coursework: {', '.join(e['coursework'])}")
    out += ["", "## Experience"]
    for x in t.experiences:
        out.append("")
        out.append(f"**{x['org']}**, *{x['role']}*, {x.get('location', '')} ({_span(x)})")
        out += [f"- {b['text']}" for b in x["bullets"]]
    if t.projects:
        out += ["", "## Projects"]
        for p in t.projects:
            out.append("")
            out.append(f"**{p['name']}**, {p.get('subtitle', '')} ({p.get('year', '')})")
            out += [f"- {b['text']}" for b in p["bullets"]]
    out += ["", "## Skills", ", ".join(t.skills)]
    if profile.get("interests"):
        out.append(f"Interests: {profile['interests']}")
    return "\n".join(out)


# ---------------------------------------------------------------- docx
def _rule(paragraph):
    p = paragraph._p
    pPr = p.get_or_add_pPr()
    bdr = OxmlElement("w:pBdr")
    bottom = OxmlElement("w:bottom")
    for k, v in (("val", "single"), ("sz", "6"), ("space", "1"), ("color", "000000")):
        bottom.set(qn(f"w:{k}"), v)
    bdr.append(bottom)
    pPr.append(bdr)


def _para(doc, text="", bold=False, italic=False, size=10, align=None, after=0, right=None):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = Pt(after)
    p.paragraph_format.space_before = Pt(0)
    if align:
        p.alignment = align
    r = p.add_run(text)
    r.bold, r.italic, r.font.size = bold, italic, Pt(size)
    if right is not None:
        p.paragraph_format.tab_stops.add_tab_stop(Inches(7.3), WD_TAB_ALIGNMENT.RIGHT)
        r2 = p.add_run("\t" + right)
        r2.font.size = Pt(size)
        r2.italic = italic
    return p


def _bullet(doc, text):
    p = doc.add_paragraph(style="List Bullet")
    p.paragraph_format.space_after = Pt(0)
    p.paragraph_format.left_indent = Inches(0.2)
    r = p.add_run(text)
    r.font.size = Pt(10)


def _base_doc():
    doc = Document()
    for s in doc.sections:
        s.top_margin = s.bottom_margin = Inches(0.35)
        s.left_margin = s.right_margin = Inches(0.4)
    st = doc.styles["Normal"]
    st.font.name = "Times New Roman"
    st.element.rPr.rFonts.set(qn("w:eastAsia"), "Times New Roman")
    st.font.size = Pt(10)
    return doc


def resume_docx(profile: dict, t: Tailored) -> bytes:
    doc = _base_doc()
    _para(doc, profile.get("name", ""), bold=True, size=16, align=WD_ALIGN_PARAGRAPH.CENTER)
    _para(doc, contact_line(profile), size=9.5, align=WD_ALIGN_PARAGRAPH.CENTER, after=2)

    def header(title):
        h = _para(doc, title.upper(), bold=True, size=10.5, after=1)
        h.paragraph_format.space_before = Pt(5)
        _rule(h)

    header("Education")
    for e in profile.get("education", []):
        _para(doc, e["school"], bold=True, right=e.get("location", ""))
        gpa = f"; GPA {e['gpa']}" if e.get("gpa") else ""
        _para(doc, f"{e['degree']}{gpa}", italic=True, right=_span(e))
        if e.get("coursework"):
            _bullet(doc, "Relevant Coursework: " + ", ".join(e["coursework"]))
    header("Professional Experience")
    for x in t.experiences:
        _para(doc, x["org"], bold=True, right=x.get("location", ""))
        _para(doc, x["role"], italic=True, right=_span(x))
        for b in x["bullets"]:
            _bullet(doc, b["text"])
    if t.projects:
        header("Projects")
        for p in t.projects:
            _para(doc, f"{p['name']} | {p.get('subtitle', '')}", bold=True, right=p.get("year", ""))
            for b in p["bullets"]:
                _bullet(doc, b["text"])
    header("Skills and Interests")
    _bullet(doc, "Skills: " + ", ".join(t.skills))
    if profile.get("interests"):
        _bullet(doc, "Interests: " + profile["interests"])
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()


def cover_letter_docx(profile: dict, letter: str) -> bytes:
    doc = _base_doc()
    for s in doc.sections:
        s.top_margin = s.bottom_margin = Inches(0.8)
        s.left_margin = s.right_margin = Inches(0.9)
    _para(doc, profile.get("name", ""), bold=True, size=14, align=WD_ALIGN_PARAGRAPH.CENTER)
    _para(doc, contact_line(profile), size=10, align=WD_ALIGN_PARAGRAPH.CENTER, after=14)
    _para(doc, date.today().strftime("%B %d, %Y"), size=11, after=10)
    for block in letter.split("\n\n"):
        _para(doc, block, size=11, after=9)
    buf = io.BytesIO()
    doc.save(buf)
    return buf.getvalue()
