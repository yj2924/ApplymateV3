"""ApplyMate: screen job descriptions against your hard rules and tailor application materials from verified facts."""

__version__ = "1.0.0"
