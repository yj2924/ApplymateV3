import copy

import pytest

from applymate.jd_parser import min_years_required, parse_jd
from applymate.profile import DEMO_PROFILE
from applymate.samples import SAMPLES
from applymate.screening import FAIL, PASS, screen
from applymate.tailor import draft_cover_letter, tailor, unsupported_numbers
from applymate import tracker


@pytest.fixture
def profile():
    return copy.deepcopy(DEMO_PROFILE)


def test_parser_splits_sections():
    jd = parse_jd(SAMPLES["Data Scientist, New Grad (good fit)"]["jd"])
    assert len(jd.required) == 3 and len(jd.preferred) == 3 and len(jd.responsibilities) == 3


def test_parser_handles_chinese_numbered_items():
    jd = parse_jd(SAMPLES["数据分析师（中文 JD）"]["jd"])
    assert len(jd.required) == 3 and len(jd.preferred) == 3


@pytest.mark.parametrize("line,years", [
    ("3+ years of experience in analytics", 3),
    ("5-8 years of product management experience", 5),
    ("2 年以上工作经验", 2),
    ("Experience with Python", None),
])
def test_years(line, years):
    got = min_years_required([line])
    assert (got[0] if got else None) == years


def test_good_fit_recommended(profile):
    s = SAMPLES["Data Scientist, New Grad (good fit)"]
    r = screen(parse_jd(s["jd"]), profile, s["company"])
    assert r.verdict == "recommended" and r.preferred_rate == 1.0


def test_no_sponsorship_and_years_fail(profile):
    s = SAMPLES["Senior Analyst (hard fail)"]
    r = screen(parse_jd(s["jd"]), profile, s["company"])
    assert r.verdict == "do_not_apply"
    hard = [c for c in r.checks if c.category == "hard" and c.status == FAIL]
    assert len(hard) == 2


def test_sponsorship_ignored_for_citizens(profile):
    profile["work_authorization"]["needs_sponsorship"] = False
    profile["preferences"]["max_years_required"] = 5
    s = SAMPLES["Senior Analyst (hard fail)"]
    r = screen(parse_jd(s["jd"]), profile, s["company"])
    assert not any(c.category == "hard" and c.status == FAIL for c in r.checks)


def test_blocked_company(profile):
    profile["preferences"]["blocked_companies"] = ["Acme"]
    s = SAMPLES["Data Scientist, New Grad (good fit)"]
    assert screen(parse_jd(s["jd"]), profile, "Acme Analytics").verdict == "do_not_apply"


def test_graduation_window_outside(profile):
    profile["graduation"] = "2025-05"
    s = SAMPLES["Data Scientist, New Grad (good fit)"]
    r = screen(parse_jd(s["jd"]), profile, s["company"])
    assert r.verdict == "do_not_apply"


def test_enrollment_required(profile):
    jd = parse_jd("Requirements\n- Must be currently enrolled in a degree program\n- Python")
    assert screen(jd, profile).verdict == "do_not_apply"


def test_low_preferred_rate(profile):
    s = SAMPLES["数据分析师（中文 JD）"]
    r = screen(parse_jd(s["jd"]), profile, s["company"])
    assert r.verdict == "not_recommended" and r.preferred_rate < 0.8


def test_never_skill_not_shown(profile):
    jd = parse_jd("Requirements\n- SAS and Python")
    assert "SAS" not in tailor(jd, profile).skills


def test_if_required_skill_only_when_asked(profile):
    assert "Mandarin" not in tailor(parse_jd("Requirements\n- Python"), profile).skills
    assert "Mandarin" in tailor(parse_jd("Requirements\n- Python and Mandarin"), profile).skills


def test_letter_uses_only_profile_numbers_and_no_dashes(profile):
    s = SAMPLES["Data Scientist, New Grad (good fit)"]
    jd = parse_jd(s["jd"])
    r = screen(jd, profile, s["company"])
    letter = draft_cover_letter(s["company"], s["role"], jd, profile, tailor(jd, profile), r.missing_skills)
    assert unsupported_numbers(letter, profile) == []
    assert "—" not in letter and "–" not in letter


def test_fact_guard_flags_invented_number(profile):
    assert unsupported_numbers("I improved revenue by 37%", profile) == ["37%"]


def test_tracker_roundtrip(tmp_path):
    db = tmp_path / "t.db"
    i = tracker.add({"company": "A", "role": "DS", "status": "Applied"}, db)
    rec = tracker.get(i, db)
    assert rec["applied_on"] and rec["follow_up_on"]
    tracker.update(i, {"status": "Interview"}, db)
    assert tracker.get(i, db)["status"] == "Interview"
    assert tracker.import_rows([{"company": "B", "role": "DA"}], path=db) == 1
    assert len(tracker.all_rows(db)) == 2
